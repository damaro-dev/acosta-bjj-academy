// database.js — Crea y configura la base de datos SQLite
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'tatami.db');
const db = new Database(DB_PATH);

// Activar foreign keys
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ── CREAR TABLAS ──────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre    TEXT NOT NULL,
    username  TEXT NOT NULL UNIQUE,
    password  TEXT NOT NULL,
    nivel     INTEGER NOT NULL DEFAULT 1,
    estado    TEXT NOT NULL DEFAULT 'activo',
    notas     TEXT DEFAULT '',
    progreso  INTEGER NOT NULL DEFAULT 0,
    ultimo_video TEXT DEFAULT '—',
    es_admin  INTEGER NOT NULL DEFAULT 0,
    creado_en TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS videos (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    num       TEXT NOT NULL,
    title     TEXT NOT NULL,
    descripcion TEXT NOT NULL DEFAULT '',
    nivel     INTEGER NOT NULL DEFAULT 1,
    duracion  TEXT NOT NULL DEFAULT '',
    vimeo_id  TEXT DEFAULT '',
    pair_id   INTEGER DEFAULT NULL,
    pair_label TEXT DEFAULT '',
    estado    TEXT NOT NULL DEFAULT 'publicado',
    creado_en TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS progreso_usuario (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL,
    video_id   INTEGER NOT NULL,
    completado INTEGER NOT NULL DEFAULT 0,
    visto_en   TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
    UNIQUE(usuario_id, video_id)
  );
`);

// ── DATOS INICIALES (solo si la BD está vacía) ────────────────
const userCount = db.prepare('SELECT COUNT(*) as c FROM usuarios').get().c;
if (userCount === 0) {
  // Crear administrador por defecto
  const adminPass = bcrypt.hashSync('admin123', 10);
  db.prepare(`
    INSERT INTO usuarios (nombre, username, password, nivel, es_admin, estado)
    VALUES (?, ?, ?, 3, 1, 'activo')
  `).run('Administrador', 'admin', adminPass);

  // Alumno de prueba
  const alumnoPass = bcrypt.hashSync('alumno123', 10);
  db.prepare(`
    INSERT INTO usuarios (nombre, username, password, nivel, es_admin, estado)
    VALUES (?, ?, ?, 1, 0, 'activo')
  `).run('Marcos Rodríguez', 'marcos_r', alumnoPass);

  console.log('✓ Usuarios iniciales creados');
  console.log('  Admin  → usuario: admin    | contraseña: admin123');
  console.log('  Alumno → usuario: marcos_r | contraseña: alumno123');
}

const videoCount = db.prepare('SELECT COUNT(*) as c FROM videos').get().c;
if (videoCount === 0) {
  const insertVideo = db.prepare(`
    INSERT INTO videos (num, title, descripcion, nivel, duracion, vimeo_id, pair_id, pair_label, estado)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const videosIniciales = [
    ['01','Caída Técnica y Rodada','Base de toda defensa en el suelo. Técnica de caída sin golpe y rodada de escape.',1,'8 min','',null,'','publicado'],
    ['02','Posición de Guardia Cerrada','Control desde abajo. Cómo mantener al rival dentro y preparar el ataque.',1,'10 min','',3,'Cómo Pasar la Guardia','publicado'],
    ['03','Cómo Pasar la Guardia','Técnicas de apertura y pasaje. Correlativo al video 02.',1,'11 min','',2,'Posición de Guardia Cerrada','publicado'],
    ['04','Llave de Brazo — Juji Gatame','Ejecución desde guardia. Control de caderas y finalización.',1,'12 min','',5,'Escapar del Juji Gatame','publicado'],
    ['05','Escapar del Juji Gatame','Defensa y salida del juji. El escape más importante del nivel 1.',1,'9 min','',4,'Llave de Brazo — Juji Gatame','publicado'],
    ['06','Triángulo desde Guardia','Ataque con piernas al cuello. Setup y finalización.',1,'13 min','',7,'Defensa del Triángulo','publicado'],
    ['07','Defensa del Triángulo','Cómo salir del triángulo antes y después de que cierren.',1,'10 min','',6,'Triángulo desde Guardia','publicado'],
  ];

  videosIniciales.forEach(v => insertVideo.run(...v));
  console.log('✓ Videos iniciales cargados');
}

module.exports = db;
