// routes/auth.js — Login y logout
const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const db = require('../database');

// POST /api/login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Usuario y contraseña requeridos.' });
  }

  const user = db.prepare(
    'SELECT * FROM usuarios WHERE username = ? AND estado = "activo"'
  ).get(username.trim().toLowerCase());

  if (!user) {
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
  }

  const passwordOk = bcrypt.compareSync(password, user.password);
  if (!passwordOk) {
    return res.status(401).json({ error: 'Usuario o contraseña incorrectos.' });
  }

  // Guardar sesión
  req.session.userId   = user.id;
  req.session.username = user.username;
  req.session.nombre   = user.nombre;
  req.session.nivel    = user.nivel;
  req.session.esAdmin  = user.es_admin === 1;

  res.json({
    ok: true,
    esAdmin: user.es_admin === 1,
    nombre: user.nombre,
    nivel: user.nivel,
  });
});

// POST /api/logout
router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

// GET /api/me — verificar sesión activa
router.get('/me', (req, res) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ logueado: false });
  }
  res.json({
    logueado: true,
    nombre: req.session.nombre,
    nivel: req.session.nivel,
    esAdmin: req.session.esAdmin,
  });
});

module.exports = router;
