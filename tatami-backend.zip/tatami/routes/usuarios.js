// routes/usuarios.js — CRUD de alumnos (solo admin)
const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const db = require('../database');
const { requireAdmin } = require('../middleware/auth');

// GET /api/usuarios — listar todos los alumnos
router.get('/', requireAdmin, (req, res) => {
  const usuarios = db.prepare(`
    SELECT id, nombre, username, nivel, estado, notas, progreso, ultimo_video, creado_en
    FROM usuarios
    WHERE es_admin = 0
    ORDER BY creado_en DESC
  `).all();
  res.json(usuarios);
});

// POST /api/usuarios — crear nuevo alumno
router.post('/', requireAdmin, (req, res) => {
  const { nombre, username, password, nivel, estado, notas } = req.body;

  if (!nombre || !username || !password) {
    return res.status(400).json({ error: 'Nombre, usuario y contraseña son obligatorios.' });
  }

  // Verificar que el username no exista
  const existe = db.prepare('SELECT id FROM usuarios WHERE username = ?').get(username.trim().toLowerCase());
  if (existe) {
    return res.status(409).json({ error: 'Ese nombre de usuario ya está en uso.' });
  }

  const hash = bcrypt.hashSync(password, 10);

  const result = db.prepare(`
    INSERT INTO usuarios (nombre, username, password, nivel, estado, notas, es_admin)
    VALUES (?, ?, ?, ?, ?, ?, 0)
  `).run(
    nombre.trim(),
    username.trim().toLowerCase(),
    hash,
    nivel || 1,
    estado || 'activo',
    notas || ''
  );

  res.json({ ok: true, id: result.lastInsertRowid });
});

// PUT /api/usuarios/:id — editar alumno
router.put('/:id', requireAdmin, (req, res) => {
  const { nombre, username, password, nivel, estado, notas } = req.body;
  const id = parseInt(req.params.id);

  const user = db.prepare('SELECT id FROM usuarios WHERE id = ? AND es_admin = 0').get(id);
  if (!user) return res.status(404).json({ error: 'Alumno no encontrado.' });

  // Si manda nueva contraseña, hashearla
  if (password && password.length >= 6) {
    const hash = bcrypt.hashSync(password, 10);
    db.prepare('UPDATE usuarios SET password = ? WHERE id = ?').run(hash, id);
  }

  db.prepare(`
    UPDATE usuarios SET
      nombre   = ?,
      username = ?,
      nivel    = ?,
      estado   = ?,
      notas    = ?
    WHERE id = ?
  `).run(nombre, username.trim().toLowerCase(), nivel, estado, notas || '', id);

  res.json({ ok: true });
});

// PATCH /api/usuarios/:id/toggle — activar/desactivar
router.patch('/:id/toggle', requireAdmin, (req, res) => {
  const id = parseInt(req.params.id);
  const user = db.prepare('SELECT estado FROM usuarios WHERE id = ? AND es_admin = 0').get(id);
  if (!user) return res.status(404).json({ error: 'Alumno no encontrado.' });

  const nuevoEstado = user.estado === 'activo' ? 'inactivo' : 'activo';
  db.prepare('UPDATE usuarios SET estado = ? WHERE id = ?').run(nuevoEstado, id);
  res.json({ ok: true, estado: nuevoEstado });
});

// DELETE /api/usuarios/:id — eliminar alumno
router.delete('/:id', requireAdmin, (req, res) => {
  const id = parseInt(req.params.id);
  db.prepare('DELETE FROM usuarios WHERE id = ? AND es_admin = 0').run(id);
  res.json({ ok: true });
});

module.exports = router;
