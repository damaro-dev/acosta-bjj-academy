// routes/videos.js — CRUD de videos + acceso del alumno
const express = require('express');
const router = express.Router();
const db = require('../database');
const { requireLogin, requireAdmin } = require('../middleware/auth');

// ── ALUMNO ────────────────────────────────────────────────────

// GET /api/videos — lista de videos según el nivel del alumno logueado
router.get('/', requireLogin, (req, res) => {
  const nivelUsuario = req.session.nivel;

  const videos = db.prepare(`
    SELECT v.*,
      CASE WHEN p.completado = 1 THEN 1 ELSE 0 END as completado
    FROM videos v
    LEFT JOIN progreso_usuario p
      ON p.video_id = v.id AND p.usuario_id = ?
    WHERE v.estado = 'publicado'
    ORDER BY CAST(v.num AS INTEGER) ASC
  `).all(req.session.userId);

  // Marcar como bloqueado si el nivel del video supera el nivel del alumno
  const result = videos.map(v => ({
    ...v,
    locked: v.nivel > nivelUsuario,
    // No mandar el vimeo_id si está bloqueado (seguridad extra)
    vimeo_id: v.nivel > nivelUsuario ? '' : v.vimeo_id,
  }));

  res.json(result);
});

// POST /api/videos/:id/completar — marcar video como completado
router.post('/:id/completar', requireLogin, (req, res) => {
  const videoId = parseInt(req.params.id);
  const userId = req.session.userId;

  db.prepare(`
    INSERT INTO progreso_usuario (usuario_id, video_id, completado)
    VALUES (?, ?, 1)
    ON CONFLICT(usuario_id, video_id) DO UPDATE SET completado = 1, visto_en = datetime('now')
  `).run(userId, videoId);

  // Actualizar progreso general del usuario
  const total = db.prepare("SELECT COUNT(*) as c FROM videos WHERE estado = 'publicado' AND nivel <= ?").get(req.session.nivel).c;
  const completados = db.prepare("SELECT COUNT(*) as c FROM progreso_usuario WHERE usuario_id = ? AND completado = 1").get(userId).c;
  const progreso = total > 0 ? Math.round((completados / total) * 100) : 0;

  db.prepare("UPDATE usuarios SET progreso = ? WHERE id = ?").run(progreso, userId);

  // Actualizar último video visto
  const video = db.prepare("SELECT title FROM videos WHERE id = ?").get(videoId);
  if (video) {
    db.prepare("UPDATE usuarios SET ultimo_video = ? WHERE id = ?").run(video.title, userId);
  }

  res.json({ ok: true, progreso });
});

// ── ADMIN — CRUD COMPLETO ─────────────────────────────────────

// GET /api/videos/admin/todos — todos los videos (incluye borradores)
router.get('/admin/todos', requireAdmin, (req, res) => {
  const videos = db.prepare('SELECT * FROM videos ORDER BY CAST(num AS INTEGER) ASC').all();
  res.json(videos);
});

// POST /api/videos — crear nuevo video
router.post('/', requireAdmin, (req, res) => {
  const { num, title, descripcion, nivel, duracion, vimeo_id, pair_id, pair_label, estado } = req.body;

  if (!title) return res.status(400).json({ error: 'El título es obligatorio.' });

  // Auto-generar número si no se pasa
  let videoNum = num;
  if (!videoNum) {
    const last = db.prepare('SELECT num FROM videos ORDER BY CAST(num AS INTEGER) DESC LIMIT 1').get();
    videoNum = last ? String(parseInt(last.num) + 1).padStart(2, '0') : '01';
  }

  const result = db.prepare(`
    INSERT INTO videos (num, title, descripcion, nivel, duracion, vimeo_id, pair_id, pair_label, estado)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    videoNum,
    title,
    descripcion || '',
    nivel || 1,
    duracion || '',
    vimeo_id || '',
    pair_id || null,
    pair_label || '',
    estado || 'publicado'
  );

  res.json({ ok: true, id: result.lastInsertRowid });
});

// PUT /api/videos/:id — editar video
router.put('/:id', requireAdmin, (req, res) => {
  const { title, descripcion, nivel, duracion, vimeo_id, pair_id, pair_label, estado } = req.body;
  const id = parseInt(req.params.id);

  const video = db.prepare('SELECT id FROM videos WHERE id = ?').get(id);
  if (!video) return res.status(404).json({ error: 'Video no encontrado.' });

  db.prepare(`
    UPDATE videos SET
      title       = ?,
      descripcion = ?,
      nivel       = ?,
      duracion    = ?,
      vimeo_id    = ?,
      pair_id     = ?,
      pair_label  = ?,
      estado      = ?
    WHERE id = ?
  `).run(title, descripcion, nivel, duracion, vimeo_id, pair_id || null, pair_label || '', estado, id);

  res.json({ ok: true });
});

// DELETE /api/videos/:id — eliminar video
router.delete('/:id', requireAdmin, (req, res) => {
  const id = parseInt(req.params.id);
  db.prepare('DELETE FROM videos WHERE id = ?').run(id);
  res.json({ ok: true });
});

module.exports = router;
